from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QTableWidget,
    QTableWidgetItem, QLineEdit, QLabel,
    QTextEdit
)
from db import get_articles, get_article_by_id 
import sys
from PyQt5.QtWidgets import QApplication


class ArticleWindow(QWidget):
    def __init__(self, article):
        super().__init__()
        self.setWindowTitle(article['title'])
        self.setGeometry(300, 300, 600, 400)
        layout = QVBoxLayout()
        self.content = QTextEdit()
        self.content.setReadOnly(True)
        self.content.setText(article['content'])
        layout.addWidget(self.content)
        self.setLayout(layout)


class MainWindow(QWidget):
    def __init__(self, user=None):
        super().__init__()
        self.user = user
        self.setWindowTitle("Wiki")
        self.setGeometry(200, 200, 900, 600)
        self.init_ui()
        self.load_articles()

    def init_ui(self):
        main_layout = QVBoxLayout()
        top_layout = QHBoxLayout()
        
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Поиск статьи...")
        self.search_input.textChanged.connect(self.load_articles)
        self.user_label = QLabel(
            f"Пользователь: {self.user['name']}" if self.user else "Гость"
        )

        self.login_button = QPushButton("Войти")
        self.create_button = QPushButton("Создать статью")

        top_layout.addWidget(self.search_input)
        top_layout.addWidget(self.user_label)
        top_layout.addWidget(self.login_button)
        top_layout.addWidget(self.create_button)

        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["ID", "Название", "Просмотры"])
        self.table.setColumnHidden(0, True)
        self.table.cellDoubleClicked.connect(self.open_article)

        main_layout.addLayout(top_layout)
        main_layout.addWidget(self.table)

        self.setLayout(main_layout)

    def load_articles(self):
        search_text = self.search_input.text()
        articles = get_articles(search_text)

        self.table.setRowCount(len(articles))

        for row, (id_, title, views) in enumerate(articles):
            self.table.setItem(row, 0, QTableWidgetItem(str(id_)))
            self.table.setItem(row, 1, QTableWidgetItem(title))
            self.table.setItem(row, 2, QTableWidgetItem(str(views)))

    def open_article(self, row, column):
        article_id = int(self.table.item(row, 0).text())
        article = get_article_by_id(article_id) 
        if article:
            self.article_window = ArticleWindow(article)
            self.article_window.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())