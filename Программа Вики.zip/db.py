import psycopg2

DB_CONFIG = {
    "dbname": "wiki",
    "user": "postgres",
    "password": "123",
    "host": "localhost",
    "port": "5432"
}

def get_connection():
    return psycopg2.connect(**DB_CONFIG)

def get_article_by_id(article_id):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, title, content, views
        FROM article
        WHERE status = 'published' AND id = %s
    """, (article_id,))

    row = cursor.fetchone()
    conn.close()

    if row:
        return {
            "id": row[0],
            "title": row[1],
            "content": row[2],
            "views": row[3]
        }
    return None


def get_articles(search_text=""):
    conn = get_connection()
    cursor = conn.cursor()

    if search_text:
        cursor.execute("""
            SELECT id, title, views
            FROM article
            WHERE status = 'published'
              AND title ILIKE %s
            ORDER BY views DESC
        """, (f"%{search_text}%",))
    else:
        cursor.execute("""
            SELECT id, title, views
            FROM article
            WHERE status = 'published'
            ORDER BY views DESC
        """)

    data = cursor.fetchall()
    conn.close()
    return data